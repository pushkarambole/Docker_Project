
# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

#__author__ = "Administrator"
#__date__ = "$Oct 23, 2019 11:02:29 PM$"
#
#if __name__ == "__main__":
#    print "Hello World"


import os
import socket 
import sys 
import datetime

#import timezone


path = '/home/data'

files = []
dict1={}
total=0
maxvalue=0

for r, d, f in os.walk(path):
    for file in f:
        if '.txt' in file:
            files.append(os.path.join(r, file))

            
            x=(os.path.join(r, file))
            
 
            with open(x, 'r') as f:
                num_words = 0
                for line in f:
                    words = line.split()
                    num_words += len(words)
                    
                dict1.update( {file : num_words} )
            
            
            #print(os)
            #print(path)
            
if dict1:            
    maxvalue= max(dict1.values())

for x, y in dict1.items():
    if y == maxvalue:
        maxName=x
        
for x, y in dict1.items():
  total +=y
  


#for x, y in dict1.items():
  #print(x, y)

#print(total)
#print(maxvalue)

host_name = socket.gethostname() 
host_ip = socket.gethostbyname(host_name) 
#print("Hostname :  ",host_name) 
#print("IP : ",host_ip)



# new_path = '/home/output/result.txt'
new_days = open('/home/output/result.txt','a')



#ts = str(now_time.strftime(fmt))
ts = str(datetime.datetime.utcnow() - datetime.timedelta(hours=4))
new_days.write("\nThis is Pushkar Sadashiv Ambole ")
new_days.write("\nList of files with their respective count:")
for x, y in dict1.items():
    new_days.write( "\n" + x + "        " + str(y))
  
new_days.write("\n \nFile " + maxName + " having maximum words as: " + str(maxvalue))
new_days.write("\nTotal number of words in all files: " + str(total))
new_days.write("\nHost name: " + host_name)
new_days.write("\nHost IP: " + host_ip)
new_days.write("\nExecuted on: " + ts)
new_days.write("\n*********************************************************\n\n\n\n")
new_days.close()

    
new_days = open('/home/output/result.txt', 'r')
file_contents = new_days.read()
print(file_contents)
new_days.close()
